/* 
 * File:   init.h
 * Author: Spork
 *
 * Created on December 26, 2013, 4:58 PM
 */

#ifndef INIT_H
#define	INIT_H

#ifdef	__cplusplus
extern "C" {
#endif

void PeripheralInit();

#ifdef	__cplusplus
}
#endif

#endif	/* INIT_H */

